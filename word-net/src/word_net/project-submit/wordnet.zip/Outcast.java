public class Outcast {

  public Outcast(WordNet wordnet) {
  }         // constructor takes a WordNet object

  public String outcast(String[] nouns) {
    return "outcast";
  }   // given an array of WordNet nouns, return an outcast

  public static void main(String[] args) {
  } // see test client below

}
